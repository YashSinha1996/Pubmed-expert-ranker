"""Utilities for rapidly calculating article scores and feature counts
across a subset of Medline."""