"""Executable scripts, some of which perform utility functions, and others
which carry out analyses for the MScanner paper results.

"""