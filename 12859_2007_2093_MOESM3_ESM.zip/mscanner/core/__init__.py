"""The core MScanner modules"""
