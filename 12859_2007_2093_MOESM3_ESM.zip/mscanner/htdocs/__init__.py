"""Package for running the MScanner web interface"""

import templates
import forms
import queue
