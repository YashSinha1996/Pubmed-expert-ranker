"""Modules for creating, reading and updating the MScanner representation of Medline"""
 